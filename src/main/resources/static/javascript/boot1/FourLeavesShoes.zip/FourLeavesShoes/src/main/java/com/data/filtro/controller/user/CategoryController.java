package com.data.filtro.controller.user;

import com.data.filtro.model.Category;
import com.data.filtro.model.Material;
import com.data.filtro.model.Product;
import com.data.filtro.service.CategoryService;
import com.data.filtro.service.MaterialService;
import com.data.filtro.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/category")
public class CategoryController {

    @Autowired
    CategoryService categoryService;

    @Autowired
    ProductService productService;

    @Autowired
    MaterialService flavorService;


    @ModelAttribute(name = "discountProducts")
    public List<Product> getDiscountProducts(Model model) {
        List<Product> productList = productService.getTopDiscountProducts();
        return productList;
    }

    public Pageable sortPage(int currentPage, int pageSize, String sortType) {
        Pageable pageable;
        switch (sortType) {
            case "product_name_asc":
                pageable = PageRequest.of(currentPage - 1, pageSize, Sort.by("productName").ascending());
                break;
            case "product_name_desc":
                pageable = PageRequest.of(currentPage - 1, pageSize, Sort.by("productName").descending());
                break;
            case "price_asc":
                pageable = PageRequest.of(currentPage - 1, pageSize, Sort.by("price").ascending());
                break;
            case "price_desc":
                pageable = PageRequest.of(currentPage - 1, pageSize, Sort.by("price").descending());
                break;
            case "newest":
                pageable = PageRequest.of(currentPage - 1, pageSize, Sort.by("createdDate").ascending());
                break;
            case "oldest":
                pageable = PageRequest.of(currentPage - 1, pageSize, Sort.by("createdDate").descending());
                break;
            default:
                pageable = PageRequest.of(currentPage - 1, pageSize, Sort.by("sold").descending());
                break;
        }
        return pageable;
    }

    @GetMapping("/{id}")
    public String showProductsByCategory(@PathVariable String id,
                                         @RequestParam(defaultValue = "0") String lowPrice,
                                         @RequestParam(defaultValue = "1000") String highPrice,
                                         @RequestParam(defaultValue = "best_selling") String sortType,
                                         @RequestParam(defaultValue = "0") String materialId,
                                         @RequestParam(defaultValue = "1") String currentPage,
//                                         @RequestParam("page") Optional<Integer> page,
                                         Model model) {
//        System.out.println("material id nhan duoc tu front end: " + materialId);
        List<Material> materialList = categoryService.getListMaterials();
//        System.out.println(materialList.get(0).getMaterialName());
        int dataLowPrice = Integer.parseInt(lowPrice);
        int dataHighPrice = Integer.parseInt(highPrice);
        int dataMaterialId = Integer.parseInt(materialId);
//        List<Product> productList = productService.findProductByPrice(dataLowPrice,dataHighPrice);
//        for (Product product: productList){
//            System.out.println(product.getProductName() + " " + product.getPrice());
//        }
//        System.out.println(dataLowPrice + " " + dataHighPrice);
//        int currentPage = page.orElse(1);
        System.out.println("currentPage = " +  currentPage);
        int dataCurrentPage = Integer.parseInt(currentPage);

        int pageSize = 6;
        int currentId = 0;
        Pageable pageable;
        Page<Product> productPage;
        Category category = null;
        String currentIdAll = "";

        pageable = sortPage(dataCurrentPage, pageSize, sortType);

        if (id.equals("all")) {
//            System.out.println("nhan vao categories");
            if (dataHighPrice != 1000 && dataMaterialId != 0){
                productPage = productService.getProductByPriceAndMaterial(dataLowPrice, dataHighPrice, dataMaterialId, pageable);
            } else if (dataHighPrice != 1000){
                productPage = productService.getProductByPrice(dataLowPrice, dataHighPrice, pageable);
            } else if (dataMaterialId != 0){
                productPage = productService.getProductByMaterial(dataMaterialId, pageable);
            } else {
                productPage = productService.getAll(pageable);
            }
            currentIdAll = "all";
        } else {
//            productPage = productService.getProductByCategory(Integer.parseInt(id), pageable);
//            productPage = productService.getProductByConditions(Integer.parseInt(id), dataLowPrice, dataHighPrice, dataMaterialId, pageable);
            if (dataHighPrice != 1000 && dataMaterialId != 0){
                productPage = productService.getProductByCategoryAndPriceAndMaterial(Integer.parseInt(id), dataLowPrice, dataHighPrice, dataMaterialId, pageable);
            } else if (dataHighPrice != 1000){
                productPage = productService.getProductByCategoryAndPrice(Integer.parseInt(id), dataLowPrice, dataHighPrice, pageable);
            } else if (dataMaterialId != 0){
                productPage = productService.getProductByCategoryAndMaterial(Integer.parseInt(id), dataMaterialId, pageable);
            } else {
                productPage = productService.getProductByCategory(Integer.parseInt(id), pageable);
            }
            category = categoryService.getCategoryById(Integer.parseInt(id));
            currentId = Integer.parseInt(id);
        }
        List<Product> productListModel = productPage.getContent();
//        List<Product> productList = productPage.getContent();
//        List<Product> productList1 = new ArrayList<>();
//        List<Product> productListModel = new ArrayList<>();
//        for (Product product : productList) {
//            if (product.getPrice() >= dataLowPrice && product.getPrice() <= dataHighPrice) {
//                productList1.add(product);
//            }
//        }
//        if (dataMaterialId != 0){
//            System.out.println("dang loc theo material");
//            for (Product product : productList1) {
//                System.out.println(product.getMaterial().getId());
//                if (product.getMaterial().getId() == dataMaterialId) {
//                    System.out.println("DAng them vao product model");
//                    productListModel.add(product);
//                }
//            }
//        } else {
//            productListModel = productList1;
//        }

        model.addAttribute("materialList",materialList);
        model.addAttribute("products", productListModel);
        model.addAttribute("totalPages", productPage.getTotalPages());
        model.addAttribute("currentPage", currentPage);
        model.addAttribute("sortType", sortType);
        model.addAttribute("category", category);
        model.addAttribute("currentId", currentId);
        model.addAttribute("currentIdAll", currentIdAll);
        model.addAttribute("dataLowPrice", dataLowPrice);
        model.addAttribute("dataHighPrice", dataHighPrice);
        model.addAttribute("dataMaterialId", dataMaterialId);
        model.addAttribute("currentPage", dataCurrentPage);
//        System.out.println("sortType: " + sortType);
        currentIdAll="";
        return "user/boot1/shop";
//        return "user/category";
    }


    @GetMapping("/flavors/{id}")
    public String showProductsByFlavor(@PathVariable Integer id,
                                       @RequestParam(defaultValue = "best_selling") String sortType,
                                       @RequestParam(name = "page") Optional<Integer> page,
                                       Model model) {

        int currentPage = page.orElse(1);
        int pageSize = 6;
        int currentFlavorId = id;
        Pageable pageable;
        Page<Product> productPage;
        Material flavor = null;

        pageable = sortPage(currentPage, pageSize, sortType);

        productPage = productService.getProductsByFlavorId(id, pageable);
        flavor = flavorService.getMaterialById(id);

        model.addAttribute("products", productPage.getContent());
        model.addAttribute("totalPages", productPage.getTotalPages());
        model.addAttribute("currentPage", currentPage);
        model.addAttribute("sortType", sortType);
        model.addAttribute("flavor", flavor);
        model.addAttribute("currentFlavorId", currentFlavorId);
        return "user/category";
    }


}
