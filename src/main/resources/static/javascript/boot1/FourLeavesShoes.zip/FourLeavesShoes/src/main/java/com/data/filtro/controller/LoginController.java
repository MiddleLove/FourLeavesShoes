package com.data.filtro.controller;

import com.data.filtro.exception.AuthenticationAccountException;
import com.data.filtro.model.*;
import com.data.filtro.service.AccountService;
import com.data.filtro.service.CartService;
import com.data.filtro.service.ProductService;
import com.data.filtro.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/login")
public class LoginController {
    private final AccountService accountService;

    private final CartService cartService;
    private final UserService userService;

    @Autowired
    private ProductService productService;

    @Autowired
    public LoginController(AccountService accountService, UserService userService, CartService cartService) {
        this.accountService = accountService;
        this.userService = userService;
        this.cartService = cartService;
    }

    @GetMapping
    public String show() {
//        List<Product> productList = productService.findProductByPrice(0,50);
//        for (Product product: productList){
//            System.out.println(product.getProductName() + " " + product.getPrice());
//        }
        return "user/boot1/login";
    }

    @PostMapping
    public String login(@RequestParam("accountName") String accountName,
                        @RequestParam("password") String password,
                        HttpSession session,
                        Model model) {
//        System.out.println("Da vao ham post logging");
        try {
            Account account = accountService.authenticateUser(accountName, password);
            User user = userService.getUserById(account.getUser().getId());
//            System.out.println(user.getName());
            session.setAttribute("account", account);
            session.setAttribute("user", user);
            Cart cart = (Cart) session.getAttribute("cart");
            GuestCart guestCart = (GuestCart) session.getAttribute("guestCart");
            if (guestCart != null) {
                cart = cartService.convertGuestCartToCart(guestCart, user);
                session.removeAttribute("guestCart");
            }
            return "redirect:/";
        } catch (AuthenticationAccountException exception) {
            exception.printStackTrace();
            System.out.println(exception.getMessage());
            model.addAttribute("message", exception.getMessage());
        }
        return "user/boot1/login";
    }

    @GetMapping("/session")
    public String check(HttpSession session) {
//        Account account = (Account) session.getAttribute("account");
//        System.out.println("session lay duoc la: " + account.getAccountName());
        return "session";
    }
}
