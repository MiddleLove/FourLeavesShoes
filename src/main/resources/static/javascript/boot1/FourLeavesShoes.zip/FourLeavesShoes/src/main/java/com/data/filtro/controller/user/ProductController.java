package com.data.filtro.controller.user;

import com.data.filtro.model.Feedback;
import com.data.filtro.model.Product;
import com.data.filtro.model.User;
import com.data.filtro.service.FeedbackService;
import com.data.filtro.service.ProductService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriUtils;

import java.nio.charset.StandardCharsets;
import java.util.List;

@Controller
@RequestMapping("/product")
public class ProductController {

    @Autowired
    ProductService productService;

    @Autowired
    FeedbackService feedbackService;

    @GetMapping
    public String product() {
        return "user/product";
    }

    @GetMapping("/{id}")
    public String product(@PathVariable Integer id, Model model) {
        int currentProductId = id;
        long maxProductId = productService.countAll();
        int t1 = 13;
        long t2 = 24;
        Product product = productService.getProductById(id);
        List<Feedback> feedbackList = feedbackService.getAllFeedBackByProductId(id);
        int numberOfFeedback = feedbackList.size();
//        System.out.println(feedbackList.get(0).getContent());
        List<Product> productList = productService.getTop4ProductsByMaterial(product.getMaterial().getId(), currentProductId);
        model.addAttribute("product", product);
        model.addAttribute("numberOfFeedback", numberOfFeedback);
        model.addAttribute("products", productList);
        model.addAttribute("currentProductId", currentProductId);
        model.addAttribute("maxProductId", maxProductId);
        model.addAttribute("feedbackList", feedbackList);
//        productList.forEach(product1 -> System.out.println(product1.getProductName()));
//        return "user/product";
        return "user/boot1/detail";
    }

    @PostMapping("/{id}/feedback")
    public String feedback(@RequestParam String content, @RequestParam("numberOfStars") int numberOfStars, @PathVariable Integer id, HttpSession session, Model model) {
        System.out.println("so luong sao: " + numberOfStars);
        Feedback feedback = new Feedback();
        feedback.setContent(content);
        feedback.setUser(null);
        feedback.setStars(numberOfStars);
        User user = (User) session.getAttribute("user");
        feedback.setUser(user);
        feedback.setProduct(productService.getProductById(id));
        feedbackService.addFeedback(feedback);
        return "redirect:/product/" + id;
    }
}
